print("I'm learning how to program in python")
print("that's awesome!")
